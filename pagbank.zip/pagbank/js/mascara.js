/*
 * PagBank
 * 
 * Módulo Oficial para Integração com o PagBank via API v.4
 * Checkout Transparente para PrestaShop 1.6.x ao 9.x
 * Pagamento com Cartão de Crédito, Google Pay, Pix, Boleto e Pagar com PagBank
 * 
 * @author
 * 2011-2026 PrestaBR - https://prestabr.com.br
 * 
 * @copyright
 * 1996-2026 PagBank - https://pagbank.com.br
 * 
 * @license
 * Open Software License 3.0 (OSL 3.0) - https://opensource.org/license/osl-3-0-php/
 *
 */

function mascara(o, f) {
  setTimeout(function () {
    o.value = f(o.value);
  }, 1);
}

function telefone(v) {
  v = v.replace(/\D/g, "");
  v = v.replace(/^(\d\d)(\d)/g, "($1) $2");
  v = v.replace(/(\d)(\d{4})$/, "$1-$2");
  return v;
}

function cpfmask(v) {
  v = v.replace(/\W/g, "");
  v = v.replace(/(\w{3})(\w)/, "$1.$2");
  v = v.replace(/(\w{3})(\w)/, "$1.$2");
  v = v.replace(/(\w{3})(\w{1,2})$/, "$1-$2");
  return v;
}

function cep(v) {
  v = v.replace(/\D/g, "");
  v = v.replace(/^(\d{5})(\d)/, "$1-$2");
  return v;
}

function cnpjmask(v) {
  v = v.replace(/\W/g, "");
  v = v.replace(/^(\w{2})(\w)/, "$1.$2");
  v = v.replace(/^(\w{2})\.(\w{3})(\w)/, "$1.$2.$3");
  v = v.replace(/\.(\w{3})(\w)/, ".$1/$2");
  v = v.replace(/(\w{4})(\w)/, "$1-$2");
  return v;
}
function data(v) {
  v = v.replace(/\D/g, "");
  v = v.replace(/(\d{2})(\d)/, "$1/$2");
  v = v.replace(/(\d{2})(\d)/, "$1/$2");
  v = v.replace(/(\d{2})(\d{2})$/, "$1$2");
  return v;
}
function creditcard(v) {
  v = v.replace(/\D/g, "");
  v = v.replace(/(.{4})/g, "$1 ");
  return v;
}

function valormask(v) {
  v = v.replace(/\D/g, "");
  v = v.replace(/(\d{1})(\d{1,2})$/, "$1.$2");
  return v;
}

function valorcardmask(v) {
  v = v.replace(/\D/g, '');
  if (v === '') return '';
  let centavos = parseInt(v, 10);
  v = centavos.toString().padStart(3, '0');
  v = v.replace(/(\d{2})$/, ',$1');
  v = v.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
  return v;
}
